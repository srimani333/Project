package com.sri.repo;

import java.io.Serializable;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.sri.bind.Worker;
import com.sri.entity.WorkerEntity;

public interface AdminRegistrationRepo extends JpaRepository<WorkerEntity, Serializable>{
	@Query("select r from RoleEntity r where roleName = ?1")
	public WorkerEntity findAllByRoleName(String rolename);

}
