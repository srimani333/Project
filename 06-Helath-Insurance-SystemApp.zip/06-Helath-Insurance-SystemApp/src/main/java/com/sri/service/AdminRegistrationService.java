package com.sri.service;

import java.util.List;

import com.sri.bind.Worker;

public interface AdminRegistrationService {
  
	public boolean saveWorker(Worker a);
	public List<Worker> getAllContact();
    public Worker getWorkerBysNo(Integer sno);

	public Worker getByRoleName(String roleName);
	public boolean updateAdmin(Worker worker);
    public void deleteView(Integer sno);
}
