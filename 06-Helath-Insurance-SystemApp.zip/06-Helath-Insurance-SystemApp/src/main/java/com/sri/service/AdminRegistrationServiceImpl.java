package com.sri.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sri.bind.Worker;
import com.sri.entity.WorkerEntity;
import com.sri.exception.ResourceNotFoundException;
import com.sri.repo.AdminRegistrationRepo;
import com.sri.repo.RoleRepository;

@Service
public class AdminRegistrationServiceImpl implements AdminRegistrationService {
 @Autowired
 private AdminRegistrationRepo repo;
 @Autowired
 private RoleRepository rolerepo;
	@Override
	public boolean saveWorker(Worker a) {
		WorkerEntity entity=new WorkerEntity();
		BeanUtils.copyProperties(a, entity);
		WorkerEntity savedentity=repo.save(entity);
		System.out.println("a"+a);
		System.out.println("save"+savedentity);
		return savedentity.getSno()!=null;
	}

	@Override
	public List<Worker> getAllContact() {
		List<Worker> list=new ArrayList<Worker>();
		List<WorkerEntity> listentity=repo.findAll();
		BeanUtils.copyProperties(listentity, list);
        System.out.println(list);
		System.out.println(listentity);
		listentity.forEach(entity->{Worker a=new Worker();
		                             a.setFirstName(entity.getFirstName());
		                             a.setLastName(entity.getLastName());
				                     a.setEmail(entity.getEmail());
				                     a.setGender(entity.getGender());
				                     a.setRoleName(entity.getRoleName());
				                     a.setSno(entity.getSno());
		
				                      list.add(a);  
		});
		System.out.println(list);
		return list;
	}

	@Override
	public Worker getByRoleName(String rolename) {
		Worker a=new Worker();
		WorkerEntity entity=repo.findAllByRoleName(rolename);
		if(entity!=null) {
			BeanUtils.copyProperties(a, entity);

		return a;
		}
		else {
			return null;
		}
	}

	@Override
	public boolean updateAdmin(Worker worker) {
		WorkerEntity entity=new WorkerEntity();
		 Optional < WorkerEntity > savedEntity = repo.findById(worker.getSno());
          
		 if(savedEntity.isPresent()) {
				BeanUtils.copyProperties(worker,entity);
				return repo.save(entity).getSno()!=null;
			}
			return false;
	}
	@Override
	public void deleteView(Integer sno) {
		repo.deleteById(sno);
	}

	@Override
	public Worker getWorkerBysNo(Integer sno) {
		Worker worker=new Worker();
		Optional<WorkerEntity> entity = repo.findById(sno);
        if (entity.isPresent()) {
            BeanUtils.copyProperties(entity.get(), worker);
            return worker;
        }
		return null; 
		
	}

	
}
