package com.sri.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name="ROLE_DTLS")
public class RoleEntity {
	@Id
	@Column(name="ROLE_ID")
	private Integer roleId;
	@Column(name="ROLE_NAME")
    private Integer roleName;
}
