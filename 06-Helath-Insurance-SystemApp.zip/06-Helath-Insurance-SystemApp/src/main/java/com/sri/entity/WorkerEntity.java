package com.sri.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;
import org.springframework.cglib.beans.BeanCopier.Generator;

import lombok.Data;

@Data
@Entity
@Table(name="Admin")
public class WorkerEntity {
 @Id
 @Column(name="S_NO")
 @GeneratedValue(strategy =GenerationType.SEQUENCE,generator = "sno" )
 @SequenceGenerator(name = "sno",sequenceName = "s_no_seq",allocationSize = 1)
 private Integer sno;
 @Column(name="FIRST_NAME")
 private String firstName;
 @Column(name="LAST_NAME")
 private String lastName;
 @Column(name="EMAIL")
 private String email;
 @Column(name="GENDER")
 private String gender;
 @Column(name="ROLE_ID")
 private Integer roleId;
 @Column(name="ROLE_NAME")
 private String roleName;
 @CreationTimestamp
 private Date createdAt;
 @CreationTimestamp
 private Date updatedAt;
}
