package com.sri.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import com.sri.bind.Worker;
import com.sri.service.AdminRegistrationService;

@Controller
public class ViewAccountController {
	@Autowired
      private AdminRegistrationService service;
	
	@GetMapping(value="/viewAccount")
	public String handleViewContactsLink(Model model,@Param("rolename")String rolename) {
		
		List<Worker> alist=service.getAllContact();
		model.addAttribute("Acc", alist);
		System.out.println("alist:"+alist);
		return "viewAccReg";
	}
	@GetMapping(value="/editView")
	public String editViewAdmin(Integer sno,Model model) {
        Worker getBySno=service.getWorkerBysNo(sno);
    	model.addAttribute("contact",getBySno);
		return "WorkerRegistration";
	}
	@GetMapping(value="/deleteView")
	public String deleteViewAdmin(Integer sno,Model model) {
        service.deleteView(sno);
		return "WorkerRegistration";
	}
	
}
