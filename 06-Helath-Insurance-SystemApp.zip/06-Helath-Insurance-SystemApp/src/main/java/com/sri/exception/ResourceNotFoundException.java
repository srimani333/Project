package com.sri.exception;

public class ResourceNotFoundException extends Exception {

	public ResourceNotFoundException(String string) {
		// TODO Auto-generated constructor stub
	}

}
