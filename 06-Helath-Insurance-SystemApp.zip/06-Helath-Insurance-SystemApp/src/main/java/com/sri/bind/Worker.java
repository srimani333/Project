package com.sri.bind;

import lombok.Data;

@Data
public class Worker {
	 private Integer sno;
	 private String firstName;
	 private String lastName;
	 private String email;
	 private String gender;
	 private Integer roleId;
	 private String roleName;
}
