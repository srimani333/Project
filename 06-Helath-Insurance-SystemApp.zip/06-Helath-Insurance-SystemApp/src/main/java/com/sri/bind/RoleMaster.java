package com.sri.bind;

import lombok.Data;

@Data
public class RoleMaster {
  private Integer roleId;
  private Integer roleName;
}
